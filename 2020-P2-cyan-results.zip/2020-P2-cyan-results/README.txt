This directory contains all the results from P2 P-day Winter 2020

Initial results for each seed are contained in the folders numbered 0 - 9.
The files that can be found stored in these folders are csv files that contain the raw data of the pen position during
the simulation and png files of the drawing output on the paper. 

Comments about results:
For every run, we start our autonomous mode right away. 
We have a calibration process in our code that is also detailed in our howto, 
but we did not run it for P-day because it takes a very long time and our simulation 
had a lot of lag.

We tested our robot on every seed, which generates a different paper to workspace transformation
matrix and identified the seed that produced the best output for us to meet
pass-fail criteria, which is to draw a closed shape with 4 clear corners. We did not meet pass-fail 
upon our initial run through of all the different arenas, but we found that seeds 5 and 9
produced results that were promising. The shape was resembling a square and was just off from being completely closed,
or there was red/blue lines indicating that the pen was tracing the desired shape but not drawing on the paper.

We tested more on seeds 5 and 9, and those test results can be found in the folder pass_fail. We put these results in 
a different folder to keep things organized and not clutter the files contained in 0-9 folders. Therefore, each folder 0-9
contains results from only 1 run. 
